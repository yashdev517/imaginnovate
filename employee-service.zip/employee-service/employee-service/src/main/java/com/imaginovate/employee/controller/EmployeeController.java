package com.imaginovate.employee.controller;

import com.imaginovate.employee.entity.Employee;
import com.imaginovate.employee.service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/emp")
@Slf4j
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/")
    public Employee saveEmployee(@RequestBody Employee employee) {
        log.info("Inside saveEmployee method of EmployeeController {}", employee);
        return employeeService.saveEmployee(employee);
    }

    @GetMapping("/{id}")
    public EmployeeDetail findEmployeeById(@PathVariable("id") Long employeeId) {
        log.info("Inside findEmployeeById method of EmployeeController {}", employeeId);
        return employeeService.findEmployeeById(employeeId);
    }
}
