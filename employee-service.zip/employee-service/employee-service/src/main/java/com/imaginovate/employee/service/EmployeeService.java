package com.imaginovate.employee.service;

import com.imaginovate.employee.controller.EmployeeDetail;
import com.imaginovate.employee.entity.Employee;
import com.imaginovate.employee.repository.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
@Slf4j
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee saveEmployee(Employee employee) {
        log.info("Inside saveEmployee method of EmployeeService {}", employee);
        return employeeRepository.save(employee);
    }

    public EmployeeDetail findEmployeeById(Long employeeId) {
        log.info("Inside findEmployeeById method of EmployeeService {}", employeeId);
        Optional<Employee> optionalEmployee = employeeRepository.findById(employeeId);
        if (optionalEmployee.isPresent()) {
            EmployeeDetail employeeDetail = new EmployeeDetail();
            employeeDetail.setEmployeeCode(optionalEmployee.get().getEmployeeId());
            employeeDetail.setFirstName(optionalEmployee.get().getFirstName());
            employeeDetail.setLastName(optionalEmployee.get().getLastName());
            employeeDetail.setYearlySalary(getYearlySalary(optionalEmployee.get().getSalary()));
            employeeDetail.setTaxAmount(getTaxAmount(optionalEmployee.get().getSalary()));
            employeeDetail.setCessAmount(getCessAmount(optionalEmployee.get().getSalary()));
            return employeeDetail;
        }
        return new EmployeeDetail();
    }

    private String getYearlySalary(BigDecimal salary) {
        //logic for yearly salary
        //return salary.multiply(BigDecimal.valueOf(12)).toPlainString();
        return null;
    }

    private String getTaxAmount(BigDecimal salary) {
        //logic for tax amount
        //return salary.multiply(BigDecimal.valueOf(12)).toPlainString();
        return null;
    }

    private String getCessAmount(BigDecimal salary) {
        //logic for tax amount
        //return salary.multiply(BigDecimal.valueOf(12)).toPlainString();
        return null;
    }
}
